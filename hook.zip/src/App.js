import React from 'react';

import './App.css';
import Registerform from "./components/Registerform";
function App() {
  return (
    <div className="App">
      <Registerform/>
    </div>
  );
}

export default App;
